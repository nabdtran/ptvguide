from __future__ import print_function
import time
import ptvapi
from ptvapi.rest import ApiException
from pprint import pprint
from datetime import datetime

devid = '3002286'
key = b'00fbeb69-7129-4cc5-8830-78391a360c38'

config = ptvapi.Configuration()
config.devid = devid
config.key = key

# create an instance of the API class
api_instance = ptvapi.DeparturesApi(ptvapi.ApiClient(config))

# Mandatory
route_type = 2 # int | Number identifying transport mode; values returned via RouteTypes API
stop_id = 21297 # int | Identifier of stop; values returned by Stops API
direction_id = 42 # int | Filter by identifier of direction of travel; values returned by Directions API - /v3/directions/route/{route_id} (optional)
max_results = 5 # int | Maximum number of results returned (optional)

# Optional
platform_numbers = [56] # list[int] | Filter by platform number at stop (optional)
look_backwards = False # bool | Indicates if filtering runs (and their departures) to those that arrive at destination before date_utc (default = false). Requires max_results &gt; 0. (optional)
gtfs = False # bool | Indicates that stop_id parameter will accept \"GTFS stop_id\" data (optional)
include_cancelled = False # bool | Indicates if cancelled services (if they exist) are returned (default = false) - metropolitan train only (optional)
expand = ['expand_example'] # list[str] | List objects to be returned in full (i.e. expanded) - options include: all, stop, route, run, direction, disruption (optional)
token = 'token_example' # str | Please ignore (optional)
signature = 'signature_example' # str | Authentication signature for request (optional)

try:
    # View departures for all routes from a stop
    api_response = api_instance.departures_get_for_stop(
        route_type=route_type,
        stop_id=stop_id,
        direction_id=direction_id,
        max_results=max_results,
        date_utc='2023-10-05T23:55:00Z'
    )
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeparturesApi->departures_get_for_stop: %s\n" % e)

