# V3BulkDeparturesStopResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stop_name** | **str** | Name of stop | [optional] 
**stop_id** | **int** | Stop identifier | [optional] 
**stop_latitude** | **float** | Geographic coordinate of latitude at stop | [optional] 
**stop_longitude** | **float** | Geographic coordinate of longitude at stop | [optional] 
**stop_suburb** | **str** | suburb of stop | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


