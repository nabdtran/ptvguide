# V3RunResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**run** | [**V3Run**](V3Run.md) | Individual trip/service of a route | [optional] 
**status** | [**V3Status**](V3Status.md) | API Status / Metadata | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


