# V3StopLocation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gps** | [**V3StopGps**](V3StopGps.md) | GPS coordinates of the stop | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


