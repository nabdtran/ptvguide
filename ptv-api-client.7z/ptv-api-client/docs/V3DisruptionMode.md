# V3DisruptionMode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**disruption_mode_name** | **str** | Name of disruption mode | [optional] 
**disruption_mode** | **int** | Disruption mode identifier | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


