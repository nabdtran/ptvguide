# V3DirectionWithDescription

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**route_direction_description** | **str** |  | [optional] 
**direction_id** | **int** | Direction of travel identifier | [optional] 
**direction_name** | **str** | Name of direction of travel | [optional] 
**route_id** | **int** | Route identifier | [optional] 
**route_type** | **int** | Transport mode identifier | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


