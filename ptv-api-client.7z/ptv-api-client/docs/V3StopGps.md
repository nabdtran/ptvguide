# V3StopGps

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**latitude** | **float** | Geographic coordinate of latitude at stop | [optional] 
**longitude** | **float** | Geographic coordinate of longitude at stop | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


