# V3OutletGeolocationResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**outlets** | [**list[V3OutletGeolocation]**](V3OutletGeolocation.md) | myki ticket outlets | [optional] 
**status** | [**V3Status**](V3Status.md) | API Status / Metadata | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


