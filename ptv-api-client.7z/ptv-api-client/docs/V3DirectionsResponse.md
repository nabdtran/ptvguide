# V3DirectionsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**directions** | [**list[V3DirectionWithDescription]**](V3DirectionWithDescription.md) | Directions of travel of route | [optional] 
**status** | [**V3Status**](V3Status.md) | API Status / Metadata | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


