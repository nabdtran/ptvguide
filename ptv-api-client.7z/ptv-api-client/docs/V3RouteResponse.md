# V3RouteResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**route** | [**V3RouteWithStatus**](V3RouteWithStatus.md) | Train lines, tram routes, bus routes, regional coach routes, Night Bus routes | [optional] 
**status** | [**V3Status**](V3Status.md) | API Status / Metadata | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


