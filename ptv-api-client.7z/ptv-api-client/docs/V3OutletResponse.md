# V3OutletResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**outlets** | [**list[V3Outlet]**](V3Outlet.md) | myki ticket outlets | [optional] 
**status** | [**V3Status**](V3Status.md) | API Status / Metadata | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


