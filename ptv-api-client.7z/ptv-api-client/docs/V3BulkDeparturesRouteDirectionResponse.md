# V3BulkDeparturesRouteDirectionResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**route_id** | **str** | Route identifier | [optional] 
**direction_id** | **int** | Direction of travel identifier | [optional] 
**direction_name** | **str** | Name of direction of travel | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


