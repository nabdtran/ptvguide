# V3RouteTypesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**route_types** | [**list[V3RouteType]**](V3RouteType.md) | Transport mode identifiers | [optional] 
**status** | [**V3Status**](V3Status.md) | API Status / Metadata | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


