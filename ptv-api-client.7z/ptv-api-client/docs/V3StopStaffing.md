# V3StopStaffing

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fri_am_from** | **str** | Stop staffing hours | [optional] 
**fri_am_to** | **str** | Stop staffing hours | [optional] 
**fri_pm_from** | **str** | Stop staffing hours | [optional] 
**fri_pm_to** | **str** | Stop staffing hours | [optional] 
**mon_am_from** | **str** | Stop staffing hours | [optional] 
**mon_am_to** | **str** | Stop staffing hours | [optional] 
**mon_pm_from** | **str** | Stop staffing hours | [optional] 
**mon_pm_to** | **str** | Stop staffing hours | [optional] 
**ph_additional_text** | **str** | Stop staffing hours | [optional] 
**ph_from** | **str** | Stop staffing hours | [optional] 
**ph_to** | **str** | Stop staffing hours | [optional] 
**sat_am_from** | **str** | Stop staffing hours | [optional] 
**sat_am_to** | **str** | Stop staffing hours | [optional] 
**sat_pm_from** | **str** | Stop staffing hours | [optional] 
**sat_pm_to** | **str** | Stop staffing hours | [optional] 
**sun_am_from** | **str** | Stop staffing hours | [optional] 
**sun_am_to** | **str** | Stop staffing hours | [optional] 
**sun_pm_from** | **str** | Stop staffing hours | [optional] 
**sun_pm_to** | **str** | Stop staffing hours | [optional] 
**thu_am_from** | **str** | Stop staffing hours | [optional] 
**thu_am_to** | **str** | Stop staffing hours | [optional] 
**thu_pm_from** | **str** | Stop staffing hours | [optional] 
**thu_pm_to** | **str** | Stop staffing hours | [optional] 
**tue_am_from** | **str** | Stop staffing hours | [optional] 
**tue_am_to** | **str** | Stop staffing hours | [optional] 
**tue_pm_from** | **str** | Stop staffing hours | [optional] 
**tue_pm_to** | **str** | Stop staffing hours | [optional] 
**wed_am_from** | **str** | Stop staffing hours | [optional] 
**wed_am_to** | **str** | Stop staffing hours | [optional] 
**wed_pm_from** | **str** | Stop staffing hours | [optional] 
**wed_pm_to** | **str** | Stop staffing hours | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


