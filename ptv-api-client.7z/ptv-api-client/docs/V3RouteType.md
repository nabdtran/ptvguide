# V3RouteType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**route_type_name** | **str** | Name of transport mode | [optional] 
**route_type** | **int** | Transport mode identifier | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


