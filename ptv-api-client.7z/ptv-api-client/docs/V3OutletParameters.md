# V3OutletParameters

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max_results** | **int** | Maximum number of results returned (default &#x3D; 30) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


