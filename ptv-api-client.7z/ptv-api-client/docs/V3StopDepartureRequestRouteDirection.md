# V3StopDepartureRequestRouteDirection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**route_id** | **str** | Identifier of route; values returned by Routes API - v3/routes | [optional] 
**direction_id** | **int** | Direction of travel identifier; values returned by Directions API - v3/directions | [optional] 
**direction_name** | **str** | Name of direction of travel; values returned by Directions API - v3/directions | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


